<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Exception;

class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function dashboard(){
        return view('backend.adminPages.dashboard');
    }

    public function doctorSchedule(){
        return view('backend.appointment.doctorSchedule');
    }

    public function viewAppointment(){
        return view('backend.appointment.viewAppointment');
    }

    public function doctorList(){
        $userList = [];
        $userList = User::join('doctor_informations','doctor_informations.doctor_id','=','users.id')
                ->join('specialists','specialists.id','=','doctor_informations.specialist_id')
                ->where('users.user_type', 'doctor')
                ->orderBy('users.id','desc')
                ->get(['users.*','doctor_informations.licence_id','specialists.specialist']);
        $data['userList'] = $userList;
        return view('backend.doctor.doctorList',['data' => $data]);
    }

    /**
     * get single doctor infromation with doctor id
     */
    function singleDoctorInfo(Request $request){
        try{
            $userList = "";
            $userList = User::join('doctor_informations','doctor_informations.doctor_id','=','users.id')
                ->join('specialists','specialists.id','=','doctor_informations.specialist_id')
                ->where('users.id',$request->id)
                ->orderBy('users.id','desc')
                ->first(['users.*','doctor_informations.twitter_url','doctor_informations.short_description','doctor_informations.long_description','doctor_informations.facebook_url','doctor_informations.instagram_url','doctor_informations.linkedin_url','doctor_informations.licence_id','doctor_informations.facebook_url','specialists.specialist']);
            $html = '';
            if(!empty($userList)){
                $html .='<div class="container emp-profile"><form method="post"><div class="row"><div class="col-md-4 mb-5"><div class="profile-img"><img src="'.asset("/doctorImage/".$userList['image']).'" alt="" /></div></div><div class="col-md-6"><div class="profile-head"><h5>'.$userList['name'].'</h5><h6>'.$userList['email'].'</h6><p class="proile-rating">RANKINGS : <span>8/10</span></p></div></div></div><div class="row"><div class="col-md-12"><ul class="nav nav-tabs" id="myTab" role="tablist"><li class="nav-item"><a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a></li><li class="nav-item"><a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Timeline</a></li></ul><div class="tab-content profile-tab" id="myTabContent"><div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab"><div class="row"><div class="col-md-4"><label>Name</label></div><div class="col-md-8"><p>'.$userList['name'].'</p></div></div><div class="row"><div class="col-md-4"><label>Email</label></div><div class="col-md-8"><p>'.$userList['email'].'</p></div></div><div class="row"><div class="col-md-4"><label>Phone</label></div><div class="col-md-8"><p>'.$userList['phone'].'</p></div></div><div class="row"><div class="col-md-4"><label>Gender</label></div><div class="col-md-8"><p>'.$userList['gender'].'</p></div></div><div class="row"><div class="col-md-4"><label>Address</label></div><div class="col-md-8"><p>'.$userList['address'].'</p></div></div><div class="row"><div class="col-md-4"><label>Location</label></div><div class="col-md-8"><p>'.$userList['location'].'</p></div></div></div><div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab"><div class="row"><div class="col-md-4"><label>Specialists</label></div><div class="col-md-8"><p>'.$userList['specialist'].'</p></div></div><div class="row"><div class="col-md-4"><label>licence Id</label></div><div class="col-md-8"><p>'.$userList['licence_id'].'</p></div></div><div class="row"><div class="col-md-4"><label>Facebook Url</label></div><div class="col-md-8"><p>'.$userList['facebook_url'].'</p></div></div><div class="row"><div class="col-md-4"><label>Instagram Url</label></div><div class="col-md-8"><p>'.$userList['instagram_url'].'</p></div></div><div class="row"><div class="col-md-4"><label>Twitter Url</label></div><div class="col-md-8"><p>'.$userList['twitter_url'].'</p></div></div><div class="row"><div class="col-md-4"><label>Linkedin Url</label></div><div class="col-md-8"><p>'.$userList['linkedin_url'].'</p></div></div><div class="row"><div class="col-md-4"><label>Short Description</label></div> <div class="col-md-8"><p>'.$userList['short_description'].'</p></div></div><div class="row"><div class="col-md-4"><label>Long Description</label> </div><div class="col-md-8"><p>'.$userList['long_description'].'</p></div></div></div></div></div></div></form></div>';
                return response()->json(['success' => true,'html'=> $html]);
            }
            return response()->json(['success' => false,'html'=> "<div class='alert alert-danger' role='alert'>No Record Found!</div>"]);
        }
        catch(Exception $ex){
            return response()->json(['success' => false,'html'=>"<div class='alert alert-danger' role='alert'>".$ex->getMessage()."</div>"]);
		}
    }

    public function patientList(){
        $userList = [];
        $userList = User::join('patient_informations','patient_informations.patient_id','=','users.id')
                ->where('users.user_type', 'patient')
                ->orderBy('users.id','desc')
                ->get(['users.*','patient_informations.dob','patient_informations.weight','patient_informations.symptom','patient_informations.allergy']);
        $data['userList'] = $userList;
        return view('backend.patient.patientList',['data' => $data]);
    }
}
