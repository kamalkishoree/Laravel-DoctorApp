<!-- start sidebar menu -->
<div class="sidebar-container">
    <div class="sidemenu-container navbar-collapse collapse fixed-menu">
        <div id="remove-scroll" class="left-sidemenu">
            <ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                <li class="sidebar-toggler-wrapper hide">
                    <div class="sidebar-toggler">
                        <span></span>
                    </div>
                </li>
                <li class="sidebar-user-panel">
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="<?php echo e(asset('doctorImage/')); ?>/<?php echo e(Auth()->user()->image); ?>" class="img-circle user-img-circle" alt="User Image" />
                        </div>
                        <div class="pull-left info">
                            <p> <?php echo e(Auth()->user()->name); ?></p>
                            <small><?php echo e(Auth()->user()->user_type); ?></small>
                        </div>
                    </div>
                </li>
                <li class="nav-item <?php echo e(Route::currentRouteName() == 'dashboard'? 'active open': ''); ?>">
                    <a href="#" class="nav-link nav-toggle">
                        <i class="material-icons">dashboard</i>
                        <span class="title">Dashboard</span>
                        <span class="selected"></span>
                        <span class="arrow open"></span>
                    </a>
                    <ul class="sub-menu">
                        <li class="nav-item  <?php echo e(Route::currentRouteName() == 'dashboard'? 'active open': ''); ?>">
                            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link ">
                                <span class="title">Overview</span>
                                <span class="selected"></span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item <?php echo e(Route::currentRouteName() == 'view-appointment'? 'active open': ''); ?> ">
                    <a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
                        <span class="title">Appointment</span><span class="arrow"></span></a>
                    <ul class="sub-menu">
                        <!-- <li class="nav-item  ">
                            <a href="<?php echo e(route('doctor-schedule')); ?>" class="nav-link "> <span class="title">Doctor Schedule</span>
                            </a>
                        </li> -->
                        <li class="nav-item <?php echo e(Route::currentRouteName() == 'view-appointment'? 'active open': ''); ?> ">
                            <a href="<?php echo e(route('view-appointment')); ?>" class="nav-link "> <span class="title">View All Appointment</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item  <?php echo e(Route::currentRouteName() == 'doctor-list'? 'active open': ''); ?>">
                    <a href="#" class="nav-link nav-toggle"> <i class="material-icons">person</i>
                        <span class="title">Doctors</span> <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li class="nav-item  <?php echo e(Route::currentRouteName() == 'doctor-list'? 'active open': ''); ?>">
                            <a href="<?php echo e(route('doctor-list')); ?>" class="nav-link "> <span class="title">Doctor List</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item  <?php echo e(Route::currentRouteName() == 'patient-list'? 'active open': ''); ?>">
                    <a href="#" class="nav-link nav-toggle"> <i class="material-icons">accessible</i>
                        <span class="title">Patients</span> <span class="arrow"></span>
                    </a>
                    <ul class="sub-menu">
                        <li class="nav-item  <?php echo e(Route::currentRouteName() == 'patient-list'? 'active open': ''); ?>">
                            <a href="<?php echo e(route('patient-list')); ?>" class="nav-link "> <span class="title">Patients List</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\laravelProjectBagicha\teleMedical\resources\views/backend/includes/sidebar.blade.php ENDPATH**/ ?>