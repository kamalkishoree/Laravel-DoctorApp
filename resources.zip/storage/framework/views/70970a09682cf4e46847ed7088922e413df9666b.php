<style>
    .modal-span {
        color: #19ce67;
    }

    .butnn {
        border: none;
        background: transparent;
        font-size: 30px;
    }

    .my-ul-nav {
        background-color: #19ce67 !important;
    }

    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        background-color: white !important;
        color: #19ce67 !important;
        font-weight: bold !important;
    }

    .main-nav-item-2 a {
        color: white;
    }

    .main-nav-item-2 a:hover {
        color: white;
    }

    .btn-success {
        color: #fff;
        background-color: #28a745;
        border-color: #28a745;
    }

    .form-control {
        height: 35px;
        padding: 0 15px;
        font-size: 15px;
        line-height: initial;
        color: #121521;
        background-color: #fff;
        border: 1px solid #eee;
        border-radius: 0;
        -webkit-transition: .5s;
        transition: .5s;
    }

    .fovia-nav .btn-primary {
        padding: 10px 22px !important;
    }

    .fovia-nav ul {
        line-height: 37px;
    }

    .od-btn-warning {
        color: #fff;
        background-color: #1f62a5;
        border-color: #1f62a5;
    }
</style>


<div class="top-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <ul class="header-contact-info">
                    <li><i class="far fa-clock"></i> Mon - Fri 09:00 - 19:00</li>
                    <li><i class="fas fa-phone"></i> Call Us: <a href="#">+9999999999</a></li>
                    <li><i class="far fa-paper-plane"></i> <a href="#"><span class="__cf_email__">loremipsum@gmail.com</span></a>
                    </li>
                </ul>
            </div>
            <div class="col-lg-4">
                <div class="header-right-content">
                    <ul class="top-header-social">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="navbar-area">
    <div class="fovia-responsive-nav">
        <div class="container">
            <div class="fovia-responsive-menu">
                <div class="logo">
                    <a href="#">
                        TELEMEDICAL 
                     </a>
                </div>
            </div>
        </div>
    </div>
    <div class="fovia-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand" href="index.html">
                    TELEMEDICAL 
                </a>
                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a href="<?php echo e(URL::to('/')); ?>" class="nav-link active">Home</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('lab')); ?>" class="nav-link">Lab</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('medicine')); ?>" class="nav-link">Medicine</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('contact-us')); ?>" class="nav-link">Contact</a></li>
                        <li class="nav-item"><a href="#" class="nav-link btn btn-primary">Login/signup</a>
                            <ul class="dropdown-menu">
                                <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#login_patient_modal">Patient</a></li>
                                <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#doctor_login_modal">Doctor
                                    </a></li>
                            </ul>
                        </li>
                        <li class="nav-item"><a href="#" class="nav-link"><img src="<?php echo e(asset('web_assets/assets/img/profile11.png')); ?>" style="    max-width: 40px;"></a>
                            <ul class="dropdown-menu">
                                <li class="nav-item"><a href="profilee.php" class="nav-link">Profile</a></li>
                                <li class="nav-item"><a href="appointment.php" class="nav-link">Appointment</a></li>
                                <li class="nav-item"><a href="#" class="nav-link">LOGOUT</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</div>


<!--  patient  login Modal are start -->
<!-- Modal -->
<div class="modal fade" id="login_patient_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="padding:2px !important;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dloginModalLabel"><b>Login As Patient</b></h5>
                <button type="button" class="close butnn" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="modal-span">×</span>
                </button>
            </div>
            <div class="modal-body">

                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="text" aria-describedby="text" placeholder="enter your mobile number">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share
                                        your email with anyone
                                        else.</small>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                                </div>
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Remember
                                        Password</label>
                                    <small class="float-right">Forget Password?</small>
                                </div>
                                <button type="submit" class="btn btn-success">Login<i class="fa fa-long-arrow-right ml-2 text-light" aria-hidden="true"></i></button>
                            </form>
                            <p class="pt-3">Don't have an account <span><b><a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#register_patient_modal">Register</a></b></span>?</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!--  patient login modal are end -->


<!--patient register modal are start -->
<!-- Modal -->

<div class="modal fade" id="register_patient_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="padding:2px !important;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logintypeLabel">Register as Patient</h5>
                <button type="button" class="close butnn" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="modal-span">×</span>
                </button>
            </div>
            <div class="modal-body">

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" aria-describedby="name" placeholder="enter your name">
                                </div><br>
                                <div class="form-group">
                                    <select class="form-control" id="exampleFormControlSelect1">
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Others</option>
                                    </select>
                                </div><br>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="enter your phone number">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share your Phone with anyone
                                        else.</small>
                                </div><br>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="location" aria-describedby="Location" placeholder="enter your location">
                                </div><br>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="enter your password">
                                </div><br>
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Allow All Terms &amp; Conditions on this site</label>
                                </div><br>
                                <button type="submit" class="btn btn-success">Register<i class="fa fa-long-arrow-right ml-2 text-light" aria-hidden="true"></i></button>
                            </form>
                            <p class="pt-3">You have all Register <span><b><a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#login_modal">Login</a></b></span>?</p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>
</div>
</div>
<!--patient register modal are end -->


<!-- doctor  login modal are start -->

<!-- Modal -->
<div class="modal fade" id="doctor_login_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">login as Doctor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="text" aria-describedby="text" placeholder="enter your mobile number">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share
                                        your email with anyone
                                        else.</small>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                                </div>
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Remember
                                        Password</label>
                                    <small class="float-right">Forget Password?</small>
                                </div>
                                <button type="submit" class="btn btn-success">Login<i class="fa fa-long-arrow-right ml-2 text-light" aria-hidden="true"></i></button>
                            </form>
                            <p class="pt-3">Don't have an account <span><b><a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#doctor_register_modal">Register</a></b></span>?</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- doctor login modal are end -->

<!-- doctor register modal are start -->
<!-- Modal -->
<div class="modal fade" id="doctor_register_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Register as Doctor</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" aria-describedby="name" placeholder="enter your name">
                                </div><br>
                                <div class="form-group">
                                    <select class="form-control" id="exampleFormControlSelect1">
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Others</option>
                                    </select>
                                </div><br>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">select Specialist</label>
                                    <select class="form-control" id="exampleFormControlSelect1">
                                        <option>Cardiologist</option>
                                        <option>Psychological</option>
                                        <option>Surgeon</option>
                                        <option>Gynecologist</option>
                                        <option>Pediatricians</option>
                                        <option>Dentist</option>
                                        <option>Breast Surgeon</option>
                                        <option>Physiotherapist</option>
                                    </select>
                                </div><br>

                                <div class="form-group">
                                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="enter your phone number">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share your Phone with anyone
                                        else.</small>
                                </div><br>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="location" aria-describedby="Location" placeholder="enter your location">
                                </div><br>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="enter your password">
                                </div><br>
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Allow All Terms &amp; Conditions on this site</label>
                                </div><br>
                                <button type="submit" class="btn btn-success">Register<i class="fa fa-long-arrow-right ml-2 text-light" aria-hidden="true"></i></button>
                            </form>
                            <p class="pt-3">You have all Register <span><b><a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#login_modal">Login</a></b></span>?</p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>
<!-- doctor register modal are end --><?php /**PATH C:\xampp\htdocs\medical\telemedical\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>