<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('web_assets/assets/css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('web_assets/assets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('web_assets/assets/css/nice-select.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('web_assets/assets/css/meanmenu.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('web_assets/assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('web_assets/assets/css/home.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('web_assets/assets/css/responsive.css')); ?>">
<title>TakecareMed</title>
<!-- <link rel="icon" type="" href="#"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><?php /**PATH C:\xampp\htdocs\laravelProjectBagicha\teleMedical\resources\views/frontend/includes/head.blade.php ENDPATH**/ ?>