hello working

<script src="https://www.gstatic.com/firebasejs/8.3.2/firebase.js"></script>

<script>
    
    var firebaseConfig = {
        apiKey: 'api-key',
        authDomain: 'project-id.firebaseapp.com',
        databaseURL: 'https://project-id.firebaseio.com',
        projectId: 'project-id',
        storageBucket: 'project-id.appspot.com',
        messagingSenderId: 'sender-id',
        appId: 'app-id',
        measurementId: 'G-measurement-id',
    };

    firebase.initializeApp(firebaseConfig);
    const messaging = firebase.messaging();

   

    messaging.onMessage(function (payload) {
        alert("hi team");
        const title = payload.notification.title;
        const options = {
            body: payload.notification.body,
            icon: payload.notification.icon,
        };
        new Notification(title, options);
    });

</script><?php /**PATH C:\xampp\htdocs\teleMedical\resources\views/frontend/pushtest.blade.php ENDPATH**/ ?>