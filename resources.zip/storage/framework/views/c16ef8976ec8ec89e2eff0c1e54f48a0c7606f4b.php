<!doctype html>
<html lang="zxx">
    <head>
        <?php echo $__env->make('frontend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>   
        <header class="header-area">
            <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>
        <!--body content start-->
            <?php echo $__env->yieldContent('content'); ?>
        <!--body content end-->
        <section class="footer-area">
             <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <div class="go-top"><i class="fas fa-chevron-up"></i></div>
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.meanmenu.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.appear.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.nice-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/main.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\medical\telemedical\resources\views/frontend/layouts/default.blade.php ENDPATH**/ ?>