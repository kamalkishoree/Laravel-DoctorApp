
<?php $__env->startSection('content'); ?>
<section class="banner">
    <div class="container">
        <div class="row">
            <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <h3>Appointment/Booking</h3>
            </div>
        </div>
    </div>
</section>
<section class="appont_tab">
    <div class="container">
        <div class="top_heading">
            <h2>Your Appointments Status</h2>
        </div>
        <div class="container my-4">
            <div class="row">
                <div class="col-md-12">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item new-item-3" role="presentation">
                            <a class="nav-link new-link-3 active text-dark" id="pills-today-tab" onclick="appointment_booking('Today')" data-toggle="pill" href="#pills-today" role="tab" aria-controls="pills-today" aria-selected="true">Today Appointments</a>
                        </li>
                        <li class="nav-item new-item-3" role="presentation">
                            <a class="nav-link new-link-3 text-dark" id="pills-approved-tab" onclick="appointment_booking('Approved')" data-toggle="pill" href="#pills-approved" role="tab" aria-controls="pills-approved" aria-selected="true">Approved Appointments</a>
                        </li>
                        <li class="nav-item new-item-3" role="presentation">
                            <a class="nav-link new-link-3 text-dark" id="pills-pending-tab" onclick="appointment_booking('Pending')" data-toggle="pill" href="#pills-pending" role="tab" aria-controls="pills-pending" aria-selected="false">Pending 
                                Appointments</a>
                        </li>

                        <li class="nav-item new-item-3" role="presentation">
                            <a class="nav-link new-link-3 text-dark" id="pills-rejected-tab" onclick="appointment_booking('Rejected')" data-toggle="pill" href="#pills-rejected" role="tab" aria-controls="pills-rejected" aria-selected="false">Rejected
                                Appointments</a>
                        </li>
                        <li class="nav-item new-item-3" role="presentation">
                            <a class="nav-link new-link-3 text-dark" id="pills-confirmed-tab" onclick="appointment_booking('Completed')" data-toggle="pill" href="#pills-confirmed" role="tab" aria-controls="pills-confirmed" aria-selected="false">Completed
                                Appointments</a>
                        </li>
                    </ul>

                    <!-- data navs section are start -->

                    <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade in show active" id="pills-today" role="tabpanel" aria-labelledby="pills-today-tab">
                            <div class="row mt-2" id="booking_Today">
                                <?php if($data['booking']->count() > 0): ?>
                                    <?php $__currentLoopData = $data['booking']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6 mb-5">
                                            <div class="card my-section-card-nek">
                                                <div class="card-header">
                                                    <?php echo e($info['doctorName']); ?> (<?php echo e($info['doctorPhone']); ?>)
                                                </div>
                                                <div class="card-body">
                                                <div class="row">
                                                        <div class="col-md-4">
                                                            <img src="<?php echo e(asset('doctorImage/'.$info['image'])); ?>">
                                                        </div>
                                                        <div class="col-md-8">
                                                            <blockquote class="blockquote mb-0">
                                                                <small class="font-weight-normal mb-2">Order Id: <?php echo e($info['order_id']); ?></small><br>
                                                                <small class="text-muted mb-2">Date :<span class="float-right"><?php echo e($info['booking_date']); ?></span></small><br>
                                                                <small class="mb-2">Disease : <span class="float-right"><?php echo e($info['specialist']); ?></span></small>
                                                                <footer class="blockquote-footer">Time Slot : <cite title="Source Title" class="float-right text-danger"></cite> <?php echo e($info['time_slot']); ?></footer>
                                                            </blockquote>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-footer">
                                                    <small class="text-muted"></small>
                                                    <div class="det_cl">
                                                        <a href="#"><i class="fa fa-video"></i></a>
                                                        <a href="#"><i class="fa fa-phone"></i></a>
                                                        <a href="" data-bs-toggle="modal" onclick="appointmentDetails(<?php echo e($info['id']); ?>)" data-bs-target="#profile"><i class="fa fa-eye"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="col-md-6">
                                        <div class='alert alert-danger' role='alert'>No Record Found</div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- --------------------approved-------------------- -->

                        <div class="tab-pane fade in" id="pills-approved" role="tabpanel" aria-labelledby="pills-approved-tab">
                            <div class="row mt-2" id="booking_Approved">
                            </div>
                        </div>

                        <!-- ------------------pending--------------------- -->

                        <div class="tab-pane fade in" id="pills-pending" role="tabpanel" aria-labelledby="pills-pending-tab">
                            <div class="row mt-2" id="booking_Pending">
                            </div>                           
                        </div>

                        <!-- -----------------Rejected--------------- -->

                        <div class="tab-pane fade in" id="pills-rejected" role="tabpanel" aria-labelledby="pills-rejected-tab">
                            <div class="row mt-2" id="booking_Rejected">
                            </div>
                        </div>
                        <!-- -----------------Completed--------------- -->
                        <div class="tab-pane fade in " id="pills-confirmed" role="tabpanel" aria-labelledby="pills-confirmed-tab">
                            <div class="row mt-2" id="booking_Completed">
                            </div>
                        </div>
                    </div>

                    <!-- data navs section are end -->
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="profile" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="max-width:1000px;">
        <div class="modal-content p-3">
            <div class="brder border border-3 border-dark">
                <div class="modal-header" style="border:none;">

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body p-0">
                    <section class="detail p-2" id="appointment-info-div">
                        

                    </section>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function appointmentDetails(id){
        $.ajax({
            url: "<?php echo e(route('appointment-info-patient')); ?>",
            type: "post",
            data: {
                id: id,
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(response) {
                console.log(response);
                $data = JSON.parse(JSON.stringify(response))
                $("#appointment-info-div").html($data['html']);
            }
        });
    }

    function appointment_booking(type){
        $.ajax({
            url: "<?php echo e(route('search-appointment-patient')); ?>",
            type: "post",
            data: {type:type,_token: "<?php echo e(csrf_token()); ?>"},
            success: function(response) {
                console.log(response);
                $data = JSON.parse(JSON.stringify(response))
                $("#booking_"+type).html($data['html']);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teleMedical\resources\views/frontend/patient/appointment.blade.php ENDPATH**/ ?>