<div class="page-footer">
    <div class="page-footer-inner"> 2021 &copy;
        <a href="" target="_top" class="makerCss">Telecare Md</a>
    </div>
    <div class="scroll-to-top">
        <i class="material-icons">eject</i>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravelProjectBagicha\teleMedical\resources\views/backend/includes/footer.blade.php ENDPATH**/ ?>