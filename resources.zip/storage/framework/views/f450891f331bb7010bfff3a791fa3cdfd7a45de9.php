
<?php $__env->startSection('content'); ?> 
<div class="page-content-wrapper">
    <div class="page-content">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title">Appointment List</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="<?php echo e(route('dashboard')); ?>">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li><a class="parent-item" href="#">Appointment</a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active">Appointment List</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card  card-box">
                    <div class="card-head">
                        <header></header>
                        <div class="tools">
                            <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                            <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                            <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                        </div>
                    </div>
                    <div class="card-body ">
                        <div class="table-scrollable">
                            <table id="tableExport" class="display table table-hover table-checkable order-column m-t-20" style="width: 100%">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th> Name </th>
                                        <th> Email </th>
                                        <th> Date Of Appointment </th>
                                        <th> From </th>
                                        <th> To </th>
                                        <th> Mobile </th>
                                        <th> Consulting Doctor </th>
                                        <th>Injury/Condition</th>
                                        <th> Action </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user6.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>jenish@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">07:15</td>
                                        <td class="center">07:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user1.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">07:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user3.jpg')); ?>" alt="">
                                        </td>
                                        <td>Pankaj Singh</td>
                                        <td>pankaj@gmal.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:45</td>
                                        <td class="center">08:00</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Sarah Smith</td>
                                        <td>Malaria</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr class="odd gradeX">
                                        <td class="patient-img">
                                            <img src="<?php echo e(asset('admin_assets/img/user/user2.jpg')); ?>" alt="">
                                        </td>
                                        <td>Jenish shah</td>
                                        <td>shah@gmail.com</td>
                                        <td class="center">12 Jan 2012</td>
                                        <td class="center">08:15</td>
                                        <td class="center">08:30</td>
                                        <td><a href="tel:444543564">
                                                444543564 </a></td>
                                        <td>Dr.Rajesh</td>
                                        <td>Fever</td>
                                        <td>
                                            <a href="" class="btn btn-tbl-edit btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                            <button class="btn btn-tbl-delete btn-xs">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelProjectBagicha\teleMedical\resources\views/backend/appointment/viewAppointment.blade.php ENDPATH**/ ?>