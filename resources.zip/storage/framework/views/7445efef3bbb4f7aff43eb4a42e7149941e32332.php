<ul class="dropdown-menu">
    <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#login_patient_modal">Patient</a></li>
    <li class="nav-item"><a href="#" class="nav-link" data-bs-toggle="modal" data-bs-target="#doctor_login_modal">Doctor
        </a></li>
</ul>


<!--  patient  login Modal are start -->
<!-- Modal -->
<div class="modal fade" id="login_patient_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="padding:2px !important;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dloginModalLabel"><b>Login As Patient</b></h5>
                <button type="button" class="close butnn" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="modal-span">×</span>
                </button>
            </div>
            <div class="modal-body">

                <div class="container-fluid">
                    <div class="row">

                        <div class="col-md-12">

                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="text" aria-describedby="text" placeholder="enter your mobile number">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share
                                        your email with anyone
                                        else.</small>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                                </div>
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Remember
                                        Password</label>
                                    <small class="float-right">Forget Password?</small>
                                </div>
                                <button type="submit" class="btn btn-success">Login<i class="fa fa-long-arrow-right ml-2 text-light" aria-hidden="true"></i></button>
                            </form>
                            <p class="pt-3">Don't have an account <span><b><a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#register_patient_modal">Register</a></b></span>?</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!--  patient login modal are end -->


<!--patient register modal are start -->
<!-- Modal -->

<div class="modal fade" id="register_patient_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="padding:2px !important;">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logintypeLabel">Register as Patient</h5>
                <button type="button" class="close butnn" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="modal-span">×</span>
                </button>
            </div>
            <div class="modal-body">

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <form>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" aria-describedby="name" placeholder="enter your name">
                                </div><br>
                                <div class="form-group">
                                    <select class="form-control" id="exampleFormControlSelect1">
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Others</option>
                                    </select>
                                </div><br>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="enter your phone number">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share your Phone with anyone
                                        else.</small>
                                </div><br>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="location" aria-describedby="Location" placeholder="enter your location">
                                </div><br>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="enter your password">
                                </div><br>
                                <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Allow All Terms &amp; Conditions on this site</label>
                                </div><br>
                                <button type="submit" class="btn btn-success">Register<i class="fa fa-long-arrow-right ml-2 text-light" aria-hidden="true"></i></button>
                            </form>
                            <p class="pt-3">You have all Register <span><b><a href="#" class="text-dark" data-bs-toggle="modal" data-bs-target="#login_modal">Login</a></b></span>?</p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\medical\telemedical\resources\views/components/login-register.blade.php ENDPATH**/ ?>