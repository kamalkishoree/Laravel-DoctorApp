

<?php $__env->startSection('content'); ?>
<div class="home-slides owl-carousel owl-theme">
    <div class="main-banner item-bg1">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="main-banner-content">
                        <span>Best Healing Service</span>
                        <h1>Tele Medical is the No. 1 Hospital</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                            ut labore et dolore magna Quis ipsumpsum dolor sit amet consectetur.</p>
                        <div class="btn-box">
                            <a href="appointment_book.php" class="btn btn-primary">Make appointment <i class="fas fa-bell"></i></a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="circle-shape1"><img src="<?php echo e(asset('web_assets/assets/img/circle-shape1.png')); ?>" alt="image"></div>
        <div class="circle-shape2"><img src="<?php echo e(asset('web_assets/assets/img/circle-shape2.png')); ?>" alt="image"></div>
        <div class="shape1"><img src="<?php echo e(asset('web_assets/assets/img/shape/1.png')); ?>" alt="image"></div>
    </div>
    <div class="main-banner item-bg2">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="main-banner-content">
                        <span>Women Care</span>
                        <h1>Exceptional Care for Women</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                            ut labore et dolore magna Quis ipsumpsum dolor sit amet consectetur.</p>
                        <div class="btn-box">
                            <a href="appointment_book.php" class="btn btn-primary">Make appointment <i class="fas fa-bell"></i></a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="circle-shape1"><img src="<?php echo e(asset('web_assets/assets/img/circle-shape1.png')); ?>" alt="image"></div>
        <div class="circle-shape2"><img src="<?php echo e(asset('web_assets/assets/img/circle-shape2.png')); ?>" alt="image"></div>
        <div class="shape1"><img src="<?php echo e(asset('web_assets/assets/img/shape/1.png')); ?>" alt="image"></div>
    </div>
    <div class="main-banner item-bg3">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="main-banner-content">
                        <span>Health Service</span>
                        <h1>Your Health is Our Top Priority</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
                            ut labore et dolore magna Quis ipsumpsum dolor sit amet consectetur.</p>
                        <div class="btn-box">
                            <a href="appointment_book.php" class="btn btn-primary">Make appointment <i class="fas fa-bell"></i></a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="circle-shape1"><img src="<?php echo e(asset('web_assets/assets/img/circle-shape1.png')); ?>" alt="image"></div>
        <div class="circle-shape2"><img src="<?php echo e(asset('web_assets/assets/img/circle-shape2.png')); ?>" alt="image"></div>
        <div class="shape1"><img src="<?php echo e(asset('web_assets/assets/img/shape/1.png')); ?>" alt="image"></div>
    </div>
</div>


<section class="main-services-area ptb-100">
    <div class="container">
        <div class="section-title">
            <span>Main Features</span>
            <h2>Our Main Services</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                et dolore magna aliqua.</p>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="main-services-box">
                    <div class="icon">
                        <i class="fa fa-user-md"></i>
                    </div>
                    <h3><a href="#">Advanced Care</a></h3>
                    <p>Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusincidunt.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="main-services-box">
                    <div class="icon">
                        <i class="fas fa-teeth"></i>
                    </div>
                    <h3><a href="#">Internal Medicine</a></h3>
                    <p>Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusincidunt.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="main-services-box">
                    <div class="icon">
                        <i class="fa fa-heartbeat"></i>
                    </div>
                    <h3><a href="#">Otolaryngology</a></h3>
                    <p>Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusincidunt.</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="main-services-box">
                    <div class="icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <h3><a href="#">Ophthalmology</a></h3>
                    <p>Lorem ipsum dolor sit amet consecte adipiscing elit sed do eiusincidunt.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="shape2"><img src="<?php echo e(asset('web_assets/assets/img/shape/2.png')); ?>" alt="image"></div>
</section>
<section class="specialist">
    <div class="container">
        <h2>Find Doctor Specialist</h2>
        <div class="row">

            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                        Cardologist
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                       Psychological
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        <!--CARD ENDS-->
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                        Surgeon
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        <!--CARD ENDS-->
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                        Gynecologist
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        <!--CARD ENDS-->
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                       Pediatrician
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        <!--CARD ENDS-->
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                        Dentist
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        <!--CARD ENDS-->
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                        Breast Surgeon
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        <!--CARD ENDS-->
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="doctor.php">
                    <div class="text_hovering_cards">
                        <!--CARD BEGINING-->
                        <div class="text_hovering_card" style="background-image:url(assets/img/flat.jpg);background-size: cover;">
                            <div class="text_hovering_card_content">
                                <section>
                                    <span class="section_left">
                                        Physiotherapist
                                    </span>
                                    <span class="section_right">
                                        <a href="doctor.php" class="card_but"><i class="fa fa-chevron-right"></i></a>
                                    </span>
                                </section>
                            </div>
                        </div>
                        <!--CARD ENDS-->
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<section class="about-area">
    <div class="container-fluid p-0">
        <div class="row m-0">
            <div class="col-lg-6 col-md-12 p-0">
                <div class="about-image">
                    <img src="<?php echo e(asset('web_assets/assets/img/about-img1.jpg')); ?>" alt="image">
                </div>
            </div>
            <div class="col-lg-6 col-md-12 p-0">
                <div class="about-content">
                    <span>About Us</span>

                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo
                        viverra maecenas accumsan lacus vel facilisis.</p>
                    <ul>
                        <li><i class="fa fa-check"></i> Scientific Skills For getting a better result</li>
                        <li><i class="fa fa-check"></i> Communication Skills to getting in touch</li>
                        <li><i class="fa fa-check"></i> A Career Overview opportunity Available</li>
                        <li><i class="fa fa-check"></i> A good Work Environment For work</li>
                    </ul>
                    <a href="#" class="btn btn-primary">Learn More <i class="fa fa-fa fa-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="our-mission-area ptb-100">
    <div class="container-fluid p-0">
        <div class="row m-0">
            <div class="col-lg-6 col-md-12 p-0">
                <div class="our-mission-content">
                    <span class="sub-title">Our Mission & Vision</span>
                    <h2>Better Information, Better Health</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.</p>
                    <ul>
                        <li>
                            <div class="icon">
                                <i class="fa fa-user-md"></i>
                            </div>
                            <span>Professional Staff</span>
                            Lorem ipsum dolor sit amet sit, consectetur adipiscing elit.
                        </li>
                        <li>
                            <div class="icon">
                                <i class="fas fa-baby"></i>
                            </div>
                            <span>Newborn Care</span>
                            Lorem ipsum dolor sit amet sit, consectetur adipiscing elit.
                        </li>
                        <li>
                            <div class="icon">
                                <i class="fas fa-vials"></i>
                            </div>
                            <span>Sufficient Lab Tests</span>
                            Lorem ipsum dolor sit amet sit, consectetur adipiscing elit.
                        </li>
                        <li>
                            <div class="icon">
                                <i class="fas fa-teeth"></i>
                            </div>
                            <span>Tooth Extraction</span>
                            Lorem ipsum dolor sit amet sit, consectetur adipiscing elit.
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 p-0">
                <div class="our-mission-image">
                    <img src="<?php echo e(asset('web_assets/assets/img/mission-img1.jpg')); ?>" alt="image">
                </div>
            </div>
        </div>
    </div>
    <div class="shape3"><img src="<?php echo e(asset('web_assets/assets/img/shape/3.png')); ?>" class="wow fadeInLeft" alt="image"></div>
</section>


<section class="fun-facts-area ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                <div class="single-fun-facts">
                    <div class="icon">
                        <i class="fa fa-user-md"></i>
                    </div>
                    <h3>
                        <span class="odometer" data-count="540"></span>
                        <span class="optional-icon">+</span>
                    </h3>
                    <p>Expert Doctors</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                <div class="single-fun-facts">
                    <div class="icon">
                        <i class="fa fa-lightbulb"></i>
                    </div>
                    <h3>
                        <span class="odometer" data-count="899"></span>
                        <span class="optional-icon">K</span>
                    </h3>
                    <p>Problem Solve</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                <div class="single-fun-facts">
                    <div class="icon">
                        <i class="fas fa-microscope"></i>
                    </div>
                    <h3>
                        <span class="odometer" data-count="100"></span>
                        <span class="optional-icon">+</span>
                    </h3>
                    <p>Award Winning</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                <div class="single-fun-facts">
                    <div class="icon">
                        <i class="fa fa-trophy"></i>
                    </div>
                    <h3>
                        <span class="odometer" data-count="56"></span>
                        <span class="optional-icon">K</span>
                    </h3>
                    <p>Experiences</p>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="services-area ptb-100 bg-f4f9fd">
    <div class="container">
        <div class="section-title">
            <span>Our Services</span>
            <h2>Our Healthcare Services</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                et dolore magna aliqua.</p>
        </div>
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-services-box bg-1">
                    <div class="icon">
                        <i class="flaticon-cancer"></i>
                    </div>
                    <h3><a href="#">Cancer Services</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore.</p>
                    <a href="#" class="read-more-btn">Read more <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-services-box bg-2">
                    <div class="icon">
                        <i class="flaticon-liver"></i>
                    </div>
                    <h3><a href="#">Liver Transplant</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore.</p>
                    <a href="#" class="read-more-btn">Read more <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-services-box bg-3">
                    <div class="icon">
                        <i class="flaticon-kidney"></i>
                    </div>
                    <h3><a href="#">Kidney Cancer</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore.</p>
                    <a href="#" class="read-more-btn">Read more <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-services-box bg-4">
                    <div class="icon">
                        <i class="flaticon-ekg"></i>
                    </div>
                    <h3><a href="#">Cardiac Arrhythmia</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore.</p>
                    <a href="#" class="read-more-btn">Read more <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-services-box bg-5">
                    <div class="icon">
                        <i class="flaticon-tooth"></i>
                    </div>
                    <h3><a href="#">Dental Services</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore.</p>
                    <a href="#" class="read-more-btn">Read more <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-services-box bg-6">
                    <div class="icon">
                        <i class="flaticon-radiation"></i>
                    </div>
                    <h3><a href="#">Radiation Oncology</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore.</p>
                    <a href="#" class="read-more-btn">Read more <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="more-services-btn">
                    <a href="#" class="btn btn-primary">More Services <i class="fa fa-fa fa-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\telemedical\resources\views/frontend/index.blade.php ENDPATH**/ ?>