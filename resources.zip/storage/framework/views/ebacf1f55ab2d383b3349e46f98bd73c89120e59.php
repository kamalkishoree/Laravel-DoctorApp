<!doctype html>
<html lang="zxx">
    <head>
        <?php echo $__env->make('frontend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body>   
        <header class="header-area">
            <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>
        <!--body content start-->
            <?php echo $__env->yieldContent('content'); ?>
        <!--body content end-->
        <section class="footer-area">
             <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <div class="go-top"><i class="fas fa-chevron-up"></i></div>
        <script src="https://www.gstatic.com/firebasejs/8.3.2/firebase.js"></script>
        <script>
            var firebaseConfig = {
                apiKey: 'api-key',
                authDomain: 'project-id.firebaseapp.com',
                databaseURL: 'https://project-id.firebaseio.com',
                projectId: 'project-id',
                storageBucket: 'project-id.appspot.com',
                messagingSenderId: 'sender-id',
                appId: 'app-id',
                measurementId: 'G-measurement-id',
            };

            firebase.initializeApp(firebaseConfig);
            const messaging = firebase.messaging();
            messaging.onMessage(function (payload) {
                $('#callModal').modal('show');
                const title = payload.notification.title;
                const options = {
                    body: payload.notification.body,
                    icon: payload.notification.icon,
                };
                new Notification(title, options);
            });

        </script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.meanmenu.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.appear.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/jquery.nice-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('web_assets/assets/js/main.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"
				type="text/javascript"></script>
<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/start/jquery-ui.css"
			rel="Stylesheet" type="text/css" />

    </body>
</html><?php /**PATH C:\xampp\htdocs\teleMedical\resources\views/frontend/layouts/default.blade.php ENDPATH**/ ?>