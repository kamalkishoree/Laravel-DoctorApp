<?php
    return  [
        'main_features' => 'Main Features',
        'main_services' => 'Our Main Services',
        'lorim_ipsum' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
        'advaced_care' => 'Advanced Care',
        'internal_medicine' => 'Internal Medicine',
        'otolaryngology' => 'Otolaryngology',
        'ophthalmology ' =>'Ophthalmology',
        'find_doctor_spec' => 'Find Doctor Specialist',
        'cardologist' => 'cardologist',
        'psychological' =>'Psychological',
        'surgeon'  => 'surgeon',
        'psychological' => 'Psychological',
        'gynecologist' => 'gynecologist',
        'pediatrician' => 'Pediatrician',
        'dentist'  => 'dentist',
        'breast_surgeon' =>'Breast Surgeon',
       'physiotherapist' => 'physiotherapist',
       'about_Us' => 'About Us',
       'lorim_ipsum' => '   Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
       labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo
       viverra maecenas accumsan lacus vel facilisis.',
       'Scientific_Skills_For_getting_a_better_result'=>'Scientific Skills For getting a better result',
       'Communication_Skills_to_getting_in_touch' =>'Communication Skills to getting in touch',
       'A_Career_Overview_opportunity_Available'=> ' A Career Overview opportunity Available',
       'learn_More' => 'Learn More',
       'our_mission_vision' => 'Our Mission Vision',
       'better_information,_better_health' => 'Better Information, Better Health',
       'lorem_ipsum' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
       labore et dolore magna aliqua.',
       'professional_staff' => 'Professional Staff',
       'lorem_ipsum' => 'Lorem ipsum dolor sit amet sit, consectetur adipiscing elit.',
       'newborn_care' => 'Newborn Care',
       'lorem_ipsum' => 'Lorem ipsum dolor sit amet sit, consectetur adipiscing elit.',
       'sufficient_lab_tests' => 'Sufficient Lab Tests',
       'lorem_ipsum' => 'Lorem ipsum dolor sit amet sit, consectetur adipiscing elit.',
       'tooth_extraction' => 'Tooth Extraction',

    ]
?>