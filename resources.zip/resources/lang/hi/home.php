<?php
    return  [
        'main_features' => 'मुख्य विशेषताएं',
    ]
?>